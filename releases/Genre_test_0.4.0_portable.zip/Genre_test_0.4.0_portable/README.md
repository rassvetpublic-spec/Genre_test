# Genre_test

**Current version: 0.4.0**

Genre_test is a local Windows-first music profiler and regression lab. Ordinary analysis combines **MAEST Discogs519 + pinned AudioSet AST + DSP** into an `AudioProfile`; Validation remains a dedicated reproducibility/drift workflow.

## What v0.4.0 outputs

Ordinary analysis can produce all three views from one inference pass:

- **Normal** — genre, family, confidence, influences, semantic tags, source metadata, BPM/key and score evidence;
- **SUNO** — compact Style of Music handoff;
- **Distributor** — broad genre/subgenre-oriented mapping.

Default GUI/CLI view is `all`.

## Architecture

```text
Audio
  +--> MAEST Discogs519 fine-style evidence ----+
  +--> AudioSet AST semantic evidence ----------+--> deterministic fusion --> AudioProfile
  +--> DSP / source metadata -------------------+                           |
                                                                            +--> Normal
                                                                            +--> SUNO
                                                                            +--> Distributor

Raw MAEST evidence ---------------------------------------------------------> Validation
```

### Pinned models

MAEST:

```text
mtg-upf/discogs-maest-30s-pw-129e-519l
revision 6c35f32a350f74351870937d5ae0bae1d898d1df
```

AudioSet AST:

```text
MIT/ast-finetuned-audioset-10-10-0.4593
revision f826b80d28226b62986cc218e5cec390b1096902
```

Result schema: **4**.

## Runtime

Supported Windows runtime:

- Python 3.11 / 3.12 / 3.13 x64;
- PyTorch 2.12.1;
- NVIDIA: CUDA 13.0 / cu130;
- Blackwell requires native active architecture; RTX 5070 Ti `sm_120` verified;
- CPU-only mode supported;
- FFmpeg required for extended decode fallback.

Runtime Health examples:

```text
GPU system: Runtime OK | Deps 12/12 | CUDA OK | GPU OK | FFmpeg OK | HF OK
CPU-only:   Runtime OK | Deps 12/12 | CUDA N/A | GPU N/A | FFmpeg OK | HF OK
```

If NVIDIA hardware exists but PyTorch CUDA is unusable, Runtime Health reports failure instead of silently treating the machine as CPU-only.

## Windows startup

### Git working copy

Clone/pull the repository and run:

```text
Genre_test_START.cmd
```

The launcher prepares/updates the private project `.venv`, reuses compatible Python/PyTorch when possible and starts the GUI.

### Portable release

Current supported package:

```text
releases/Genre_test_0.4.0_portable.zip
```

The same archive is attached to GitHub Release `v0.4.0` together with `SHA256SUMS.txt`.

The package does not contain Python, PyTorch or model weights. First launch prepares them automatically and uses normal user pip/Hugging Face caches while keeping the project `.venv` isolated.

## GUI

The Runtime Health window has three tabs:

```text
Анализ | Validation | Проверка
```

### Анализ

- source file/folder selection;
- Device `auto/cpu/cuda` when CUDA is actually available;
- Auto / Fast / Accurate / Expert modes;
- Normal / SUNO / Distributor / all views;
- optional full source path;
- Expert MAEST window count and Top-K;
- Safe Stop;
- dark theme by default with live Dark / Light switch;
- clickable History/log locations.

Live mode/view/path/device changes are applied safely at track boundaries.

### Validation

Re-analyzes selected sources to measure convergence and history drift.

- Fast / Auto / Accurate or full Fast+Auto+Accurate comparison;
- all / stale-or-missing-build / unstable filters;
- explicit `DRIFT: STABLE/MINOR/SIGNIFICANT/CRITICAL` terminology;
- Safe Stop preserves completed results.

### Проверка

Compares saved builds without re-analyzing audio.

Build identity includes analyzer version + Git commit + schema + model revision. A preflight reports Build A coverage, Build B coverage and common tracks; 0-common-track comparisons are refused instead of emitting meaningless 0% metrics. Repeatability mode compares two runs of the same build.

## Analysis modes

| Mode | Behavior |
|---|---|
| Auto | default adaptive analysis; expands when evidence is ambiguous |
| Fast | up to 3 representative MAEST windows |
| Accurate | full duration-based target |
| Expert | manual window count and Top-K |

Duration target:

| Duration | Maximum MAEST windows |
|---:|---:|
| < 60 s | 1 |
| 60–120 s | 3 |
| 120–210 s | 5 |
| 210–300 s | 7 |
| 300–420 s | 9 |
| > 420 s | 11 |

## Input QC

```text
< 10 s   -> INSUFFICIENT_AUDIO, no genre verdict
10-30 s  -> SHORT_INPUT, one padded MAEST window, confidence <= medium
>= 30 s  -> NORMAL
```

## Tempo and source metadata

Tempo-v2 handles:

- normal BPM candidate;
- half/double-time relationships;
- short-loop 3:2 ambiguity.

The report exposes alternate tempo candidates, but stable repeated output is not treated as independent BPM ground truth.

Source sample rate, bit depth, channels and bitrate come from the original audio file and are not confused with the internal 16 kHz MAEST stream.

## History paths

Default working-copy runtime data:

```text
C:\GIT\Genre_test\.genre_test\history.sqlite3
C:\GIT\Genre_test\.genre_test\logs\genre_test.log
C:\GIT\Genre_test\results\
```

History is gitignored. Historical JSON import remains available as a migration/data-recovery feature, but old portable release bootstrap semantics are not part of the active repository.

## CLI

Version and diagnostics:

```powershell
.\.venv\Scripts\genre-test.exe --version
.\.venv\Scripts\genre-test.exe doctor
```

Single file:

```powershell
.\.venv\Scripts\genre-test.exe analyze "D:\Music\track.wav" --view all
```

Recursive batch:

```powershell
.\.venv\Scripts\genre-test.exe batch "D:\Music" --device auto --mode auto --semantic auto --view all --full-path
```

Validation:

```powershell
.\.venv\Scripts\genre-test.exe validate "D:\Music" --filter all
.\.venv\Scripts\genre-test.exe validate "D:\Music" --compare-modes --filter all
```

Large repeatable regression:

```powershell
.\scripts\run_large_regression.ps1 -Source "D:\Music" -CompareModes
```

Omit `-CompareModes` for a faster Auto-only validation pass.

## Current release evidence

Accepted v0.4 release gates include:

- Windows ensemble batch: 25/25 complete, semantic 25/25, file errors 0;
- Accurate Validation: 25/25, file errors 0;
- Safe Stop verified;
- CUDA/Blackwell runtime verified on RTX 5070 Ti;
- CI on Python 3.11 / 3.12 / 3.13 with Ruff, pytest and PowerShell/CUDA gates.

## Known development items

- shared audio decode/cache between MAEST and AST;
- persistent semantic cache;
- explicit fine-style ambiguity presentation for near-tied Top-1/Top-2 results;
- independent BPM ground-truth fixtures;
- classical resolver/calibration;
- larger reviewed benchmark/confusion analysis;
- similarity, XLSX and richer calibrated descriptors.

See [ROADMAP.md](ROADMAP.md) and [docs/ACTIVE_CURRENT.md](docs/ACTIVE_CURRENT.md).
