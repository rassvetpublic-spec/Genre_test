# Что держать в Sources после v1.4.1

Минимальный активный набор:

```text
OZONE12_MASTERING_LAB_UNIVERSAL_CORE_v1_4_1.zip
source WAV текущего трека
current base/winner XML
lyrics/style/current task
optional MP3/previous renders as labeled references
```

После добавления **v1.4.1** удалить прежний `OZONE12_MASTERING_LAB_UNIVERSAL_CORE_v1.4.zip` из активных Sources. Это исправляет прежнюю двусмысленную инструкцию и не удаляет новый v1.4.1 package.

Старые простые источники из `tables/source_replacement_coverage_v1_3.csv` можно убрать из активного набора. Трековые архивы хранить отдельно и не использовать как универсальные defaults.
